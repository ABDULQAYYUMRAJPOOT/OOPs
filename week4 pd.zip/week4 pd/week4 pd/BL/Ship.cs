﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace week4_pd.BL
{
    internal class Ship
    {
        public string Serial;
        public Angle lat_angle = new Angle();
        public Angle longi_angle = new Angle();
        public Ship()
        {

        }
        public Ship(string serial, Angle lat, Angle longi)
        {
            this.Serial = serial;
            this.lat_angle = lat;
            this.longi_angle = longi;

        }
        
        public string serial()
        {
            return Serial;
        }
        public string position()
        {
            string sr = "The Ship is  at: "+this.lat_angle.degrees+ "\u00b0" + this.lat_angle.minutes + "'  " + this.lat_angle.direction + "  and  "+this.longi_angle.degrees + "\u00b0" + this.longi_angle.minutes + "'  " + this.longi_angle.direction;
            return sr;
        }
        public  void changePosition(int laDeg, float laMin, Char laDir, int loDeg, float loMin, Char loDir)
        {
            this.lat_angle.degrees = laDeg;
            this.lat_angle.minutes = laMin;
            this.lat_angle.direction = laDir;
            this.longi_angle.degrees = loDeg;
            this.longi_angle.minutes = loMin;
            this.longi_angle.direction = loDir;
        }
    }
}
