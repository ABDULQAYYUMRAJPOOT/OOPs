﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace week4_pd.BL
{
    internal class Angle
    {
        public int degrees;
        public float minutes;
        public Char direction;
        public Angle()
        {

        }
        public Angle(int degrees, float minutes, Char direction)
        {
            this.degrees = degrees;
            this.minutes = minutes;
            this.direction = direction;
        }
    }
}
