﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using week4_pd.BL;

namespace week4_pd
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Ship> ships = new List<Ship>();
            string input;
            int lat_deg, longi_deg; 
            float lat_min, longi_min;
            Char longi_dir, lat_dir;
            Ship s = new Ship();
            Char option;
            while(true)
            {
                option = takeInput();
                if(option == '1')
                {
                    s = inputShip();
                    if (s != null)
                    {
                        ships.Add(s);
                    }
                    Console.ReadKey();
                }
                else if( option == '2')
                {
                    Console.Write("Enter Ship's serial number: ");
                    input = Console.ReadLine();
                    if (input != null)
                    {
                        s = showPosition(ships, input);
                        if(s != null)
                        {
                            Console.WriteLine(s.position());
                        }
                    }
                    Console.ReadKey();
                }
                else if (option == '3')
                {
                    Console.Write("Enter Latitude's Degrees: ");
                    lat_deg = int.Parse(Console.ReadLine());
                    Console.Write("Enter Latitude's Minutes: ");
                    lat_min = float.Parse(Console.ReadLine());
                    Console.Write("Ënter Latitude's direction 'W', 'E', 'S' or 'N': ");
                    lat_dir = Char.Parse(Console.ReadLine());
                    Console.Write("Enter Ship's Longitude in Degrees: ");
                    longi_deg = int.Parse(Console.ReadLine());
                    Console.Write("Enter Ship's Longitude in Minutes: ");
                    longi_min = float.Parse(Console.ReadLine());
                    Console.Write("Enter Longitude's direction 'W', 'E', 'S' or 'N': ");
                    longi_dir = Char.Parse(Console.ReadLine());
                    if(lat_deg >= 0 && lat_min >= 0 && longi_deg >= 0 && longi_min>= 0 && longi_dir>= 65 && longi_dir<=95 && lat_dir >= 65 && lat_dir <= 95)
                    {
                        string flag = showSerial(ships, lat_deg, lat_min, lat_dir, longi_deg, longi_min, longi_dir);
                        if(flag != null)
                        {
                            Console.WriteLine("Ship's serial number is: "+flag);
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine("Information does not match...");
                            Console.ReadKey();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid Input...");
                        Console.ReadKey();  
                    }
                }
                else if(option == '4')
                {
                    Console.Write("Enter Serial Number of Ship: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Latitude's Degrees: ");
                    lat_deg = int.Parse(Console.ReadLine());
                    Console.Write("Enter Latitude's Minutes: ");
                    lat_min = float.Parse(Console.ReadLine());
                    Console.Write("Ënter Latitude's direction 'W', 'E', 'S' or 'N': ");
                    lat_dir = Char.Parse(Console.ReadLine());
                    Console.Write("Enter Ship's Longitude in Degrees: ");
                    longi_deg = int.Parse(Console.ReadLine());
                    Console.Write("Enter Ship's Longitude in Minutes: ");
                    longi_min = float.Parse(Console.ReadLine());
                    Console.Write("Enter Longitude's direction 'W', 'E', 'S' or 'N': ");
                    longi_dir = Char.Parse(Console.ReadLine());
                    if (name != null&& lat_deg >= 0 && lat_min >= 0 && longi_deg >= 0 && longi_min >= 0 && longi_dir >= 65 && longi_dir <= 95 && lat_dir >= 65 && lat_dir <= 95)
                    {
                        bool flag = changePosition(ships, name, lat_deg, lat_min, lat_dir, longi_deg, longi_min, longi_dir);
                        if (flag == true)
                        {
                            Console.WriteLine("Changed successfully...");
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine("Serial does not match...");
                            Console.ReadKey();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid Input...");
                        Console.ReadKey();
                    }
                }
                else if(option == '5')
                {
                    break;
                }
            }

            

        }
        static Char takeInput()
        {
            Char option;
            Console.Clear();
            Console.WriteLine("Enter 1 to add ship");
            Console.WriteLine("Enter 2 to view ship position");
            Console.WriteLine("Enter 3 to view ship serial");
            Console.WriteLine("Enter 4 to change ship positions");
            Console.WriteLine("Enter 5 to Exit");
            return option = Char.Parse(Console.ReadLine());
        }
        static Ship inputShip() 
        {
            Console.Write("Enter Serial Number of Ship: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Ship's Latitude::");
            Console.Write("Enter Latitude's Degrees: ");
            int lat_deg = int.Parse(Console.ReadLine());
            Console.Write("Enter Latitude's Minutes: ");
            float lat_min = float.Parse(Console.ReadLine());
            Console.Write("Ënter Latitude's direction 'W', 'E', 'S' or 'N': ");
            Char lat_dir = Char.Parse(Console.ReadLine());
            Angle lat_angle = new Angle(lat_deg, lat_min, lat_dir);
            Console.WriteLine("Enter Ship's Longitude::");
            Console.Write("Enter Ship's Longitude in Degrees: ");
            int lon_deg = int.Parse(Console.ReadLine());
            Console.Write("Enter Ship's Longitude in Minutes: ");
            float lon_min = float.Parse(Console.ReadLine());
            Console.Write("Enter Longitude's direction 'W', 'E', 'S' or 'N': ");
            Char lon_dir = Char.Parse(Console.ReadLine());
            Angle lon_angle = new Angle(lon_deg, lon_min, lon_dir);
            Ship s = new Ship(name, lat_angle, lon_angle);
            return s;

        }
        static Ship showPosition(List<Ship> s, string input)
        {
            foreach(var  ship in s) 
            {
                if(input == ship.Serial) 
                {
                    return ship;
                }
            }
            return null;
        }
        static string showSerial(List<Ship> s, int latDeg, float latMin, Char latDir, int loDeg, float loMin, Char loDir)
        {
            foreach(var ship in s)
            {
                if (ship.lat_angle.degrees == latDeg && ship.lat_angle.minutes == latMin && ship.lat_angle.direction == latDir && ship.longi_angle.degrees == loDeg && ship.longi_angle.minutes == loMin && ship.longi_angle.direction == loDir)
                {
                    return ship.serial();
                }
            }
            return null;
        }
        static bool changePosition(List<Ship> s, string name,int latDeg, float latMin, Char latDir, int loDeg, float loMin, Char loDir)
        {
            foreach (var ship in s)
            {
                if (ship.Serial == name)
                {
                    ship.changePosition(latDeg, latMin, latDir, loDeg, loMin, loDir);
                    return true;
                }
            }
            return false;
        }
    }
}
